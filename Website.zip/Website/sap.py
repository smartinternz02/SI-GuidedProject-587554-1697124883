from flask import Flask, render_template

sap = Flask(__name__, static_url_path='/static')

@sap.route('/')
def fun():
    return render_template('index.html')

if __name__ == "__main__":
    sap.run(debug=True, port=5000)
